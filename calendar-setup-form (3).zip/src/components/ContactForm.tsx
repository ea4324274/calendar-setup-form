import React, { useState, useCallback, FormEvent } from 'react';
import { FormData, FormErrors, WeeklyHours } from '../types';
import { Input } from './form/Input';
import { Textarea } from './form/Textarea';
import { Button } from './form/Button';
import { RadioGroup } from './form/RadioGroup';
import { AvailabilityEditor } from './form/AvailabilityEditor';

const initialFormData: FormData = {
  name: '',
  email: '',
  weeklyHours: {
    monday: [{ start: '09:00', end: '17:00' }],
    tuesday: [{ start: '09:00', end: '17:00' }],
    wednesday: [{ start: '09:00', end: '17:00' }],
    thursday: [{ start: '09:00', end: '17:00' }],
    friday: [{ start: '09:00', end: '17:00' }],
    saturday: [],
    sunday: [],
  },
  preBuffer: '15',
  postBuffer: '15',
  sameDayCutoff: '4',
  advanceBookingWindow: '30',
  maxAppointmentsPerDay: '',
  regularBreaks: 'Mon-Fri 12:00-13:00',
  bookingTypes: '',
  appointmentApproval: 'auto',
  notes: '',
};

const initialErrors: FormErrors = {};

//
// PASTE YOUR GOOGLE APPS SCRIPT URL HERE
// ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️
const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzgZXqT5T_N-hjxn8-JHp6gHhNn9ug61IKKiv-ccAw4iy4msYcqS8_IhwKAxPINfSJClw/exec';
// ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️
//

export const CalendarSetupForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [errors, setErrors] = useState<FormErrors>(initialErrors);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const validate = useCallback((): boolean => {
    const newErrors: FormErrors = {};
    
    // Section 1
    if (!formData.name.trim()) newErrors.name = 'Full Name is required.';
    if (!formData.email.trim()) {
      newErrors.email = 'Google Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid.';
    }

    // Section 2
    const hasHours = Object.values(formData.weeklyHours).some(day => day.length > 0 && day.some(slot => slot.start && slot.end));
    if (!hasHours) {
        newErrors.weeklyHours = 'Please add at least one time slot for your availability.';
    }
    if (!formData.preBuffer.trim() || isNaN(Number(formData.preBuffer))) newErrors.preBuffer = 'Required, must be a number.';
    if (!formData.postBuffer.trim() || isNaN(Number(formData.postBuffer))) newErrors.postBuffer = 'Required, must be a number.';
    if (!formData.sameDayCutoff.trim() || isNaN(Number(formData.sameDayCutoff))) newErrors.sameDayCutoff = 'Required, must be a number.';
    if (!formData.advanceBookingWindow.trim() || isNaN(Number(formData.advanceBookingWindow))) newErrors.advanceBookingWindow = 'Required, must be a number.';

    // Section 3
    if (!formData.bookingTypes.trim()) newErrors.bookingTypes = 'Booking types & durations are required.';
    if (!formData.appointmentApproval) newErrors.appointmentApproval = 'Please select an appointment approval method.';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [formData]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if(errors[name as keyof FormErrors]) {
        setErrors(prev => ({...prev, [name]: undefined}));
    }
  }, [errors]);

  const handleAvailabilityChange = useCallback((weeklyHours: WeeklyHours) => {
    setFormData(prev => ({ ...prev, weeklyHours }));
    if (errors.weeklyHours) {
      setErrors(prev => ({ ...prev, weeklyHours: undefined }));
    }
  }, [errors.weeklyHours]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }

    if (GOOGLE_SCRIPT_URL.includes('YOUR_DEPLOYMENT_ID') || !GOOGLE_SCRIPT_URL.startsWith('https://script.google.com')) {
        console.error("Please replace the placeholder GOOGLE_SCRIPT_URL with your actual Google Apps Script deployment URL.");
        setSubmissionStatus('error');
        return;
    }

    setIsSubmitting(true);
    setSubmissionStatus('idle');

    try {
      const response = await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors',
        cache: 'no-cache',
        body: JSON.stringify(formData),
        redirect: 'follow',
      });

      setSubmissionStatus('success');
      setFormData(initialFormData);

    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmissionStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const FormSection: React.FC<{title: string; children: React.ReactNode}> = ({title, children}) => (
    <fieldset className="border-t border-slate-700 pt-6 mt-6 first:border-t-0 first:pt-0 first:mt-0">
        <legend className="text-lg font-semibold text-cyan-400 mb-4 px-2 -ml-2">{title}</legend>
        <div className="space-y-6">
            {children}
        </div>
    </fieldset>
  );

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-8 shadow-2xl shadow-slate-950/50">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-cyan-400">Calendar Setup</h1>
        <p className="text-slate-400 mt-2">Configure your scheduling and availability settings.</p>
      </div>
      
      <form onSubmit={handleSubmit} noValidate className="space-y-6">
        <FormSection title="Section 1 — Basics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input label="1. Full Name" id="name" name="name" value={formData.name} onChange={handleChange} error={errors.name} placeholder="John Doe" required />
                <Input label="2. Google Email for Calendar" id="email" name="email" type="email" value={formData.email} onChange={handleChange} error={errors.email} placeholder="john.doe@gmail.com" required />
            </div>
        </FormSection>
        
        <FormSection title="Section 2 — Availability & Buffers">
             <div>
                <label className="block mb-2 text-sm font-medium text-slate-300">3. Weekly Hours</label>
                <AvailabilityEditor value={formData.weeklyHours} onChange={handleAvailabilityChange} error={errors.weeklyHours} />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <Input label="4. Pre-Buffer (mins)" id="preBuffer" name="preBuffer" type="number" value={formData.preBuffer} onChange={handleChange} error={errors.preBuffer} required />
                <Input label="5. Post-Buffer (mins)" id="postBuffer" name="postBuffer" type="number" value={formData.postBuffer} onChange={handleChange} error={errors.postBuffer} required />
                <Input label="6. Same-day Cutoff (hrs)" id="sameDayCutoff" name="sameDayCutoff" type="number" value={formData.sameDayCutoff} onChange={handleChange} error={errors.sameDayCutoff} required />
                <Input label="7. Advance Window (days)" id="advanceBookingWindow" name="advanceBookingWindow" type="number" value={formData.advanceBookingWindow} onChange={handleChange} error={errors.advanceBookingWindow} required />
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input label="8. Max Appointments per Day" id="maxAppointmentsPerDay" name="maxAppointmentsPerDay" type="number" value={formData.maxAppointmentsPerDay} onChange={handleChange} error={errors.maxAppointmentsPerDay} placeholder="Optional"/>
                <Textarea label="9. Regular Breaks/Lunch" id="regularBreaks" name="regularBreaks" value={formData.regularBreaks} onChange={handleChange} error={errors.regularBreaks} placeholder="e.g., “M–F 1:00–1:30p” (Optional)" rows={2} />
             </div>
        </FormSection>

        <FormSection title="Section 3 — Booking Types & Notes">
            <Textarea 
              label="10. Booking Types & Durations"
              id="bookingTypes"
              name="bookingTypes"
              value={formData.bookingTypes}
              onChange={handleChange}
              error={errors.bookingTypes}
              placeholder="e.g., 30-min Intro Call, 60-min Consultation"
              rows={4}
              required
            >
                <p className="text-xs text-slate-400 mt-1">Please review the existing types in the Calendar Set and list any modifications (add/remove, rename, duration changes, buffers per service, staff-only vs public).</p>
            </Textarea>
             <RadioGroup
              label="11. Appointment Approval"
              name="appointmentApproval"
              value={formData.appointmentApproval}
              onChange={handleChange}
              error={errors.appointmentApproval}
              options={[
                { value: 'auto', label: 'Auto-confirm' },
                { value: 'manual', label: 'Manual approval' },
              ]}
            />
            <Textarea label="12. Anything else we should know?" id="notes" name="notes" value={formData.notes} onChange={handleChange} error={errors.notes} placeholder="Optional" rows={3}/>
        </FormSection>


        <div className="pt-2">
            <Button type="submit" disabled={isSubmitting} isLoading={isSubmitting}>
                {isSubmitting ? 'Submitting...' : 'Submit Configuration'}
            </Button>
        </div>

        {submissionStatus === 'success' && (
            <div className="mt-4 text-center p-3 rounded-lg bg-green-500/10 text-green-400 border border-green-500/20">
                Configuration submitted successfully! We'll check our sheet for the entry.
            </div>
        )}
        {submissionStatus === 'error' && (
            <div className="mt-4 text-center p-3 rounded-lg bg-red-500/10 text-red-400 border border-red-500/20">
                Something went wrong. Please ensure you have the correct Google Apps Script URL.
            </div>
        )}
      </form>
    </div>
  );
};
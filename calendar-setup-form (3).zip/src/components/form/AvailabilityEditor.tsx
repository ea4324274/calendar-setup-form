import React from 'react';
import { WeeklyHours } from '../../types';

const SmallButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement>> = ({ children, ...props }) => (
    <button
        type="button"
        className="px-2 py-1 text-xs font-medium rounded bg-cyan-600 hover:bg-cyan-700 text-white transition-colors"
        {...props}
    >
        {children}
    </button>
);

const RemoveButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement>> = ({ children, ...props }) => (
    <button
        type="button"
        aria-label="Remove time slot"
        className="flex items-center justify-center h-6 w-6 text-xs font-medium rounded-full bg-slate-700 hover:bg-red-600 text-white transition-colors"
        {...props}
    >
        {children}
    </button>
);

interface AvailabilityEditorProps {
  value: WeeklyHours;
  onChange: (value: WeeklyHours) => void;
  error?: string;
}

const daysOfWeek = [
  { key: 'monday', label: 'Monday' },
  { key: 'tuesday', label: 'Tuesday' },
  { key: 'wednesday', label: 'Wednesday' },
  { key: 'thursday', label: 'Thursday' },
  { key: 'friday', label: 'Friday' },
  { key: 'saturday', label: 'Saturday' },
  { key: 'sunday', label: 'Sunday' },
];

export const AvailabilityEditor: React.FC<AvailabilityEditorProps> = ({ value, onChange, error }) => {
  const handleAddTimeSlot = (dayKey: string) => {
    const newWeeklyHours = { ...value };
    if (!newWeeklyHours[dayKey]) {
      newWeeklyHours[dayKey] = [];
    }
    newWeeklyHours[dayKey].push({ start: '', end: '' });
    onChange(newWeeklyHours);
  };

  const handleRemoveTimeSlot = (dayKey: string, index: number) => {
    const newWeeklyHours = { ...value };
    newWeeklyHours[dayKey].splice(index, 1);
    onChange(newWeeklyHours);
  };

  const handleTimeChange = (dayKey: string, index: number, field: 'start' | 'end', time: string) => {
    const newWeeklyHours = JSON.parse(JSON.stringify(value)); // Deep copy
    newWeeklyHours[dayKey][index][field] = time;
    onChange(newWeeklyHours);
  };

  return (
    <div className="space-y-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700">
        {daysOfWeek.map(({ key, label }) => (
            <div key={key} className="grid grid-cols-1 md:grid-cols-[100px_1fr] gap-4 items-start">
                <label className="font-medium text-slate-300 pt-2 text-sm">{label}</label>
                <div className="space-y-2">
                    {(value[key] || []).length === 0 && (
                        <span className="text-sm text-slate-500 italic inline-block pt-2">Unavailable</span>
                    )}
                    {(value[key] || []).map((slot, index) => (
                        <div key={index} className="flex items-center gap-2">
                             <input
                                type="time"
                                aria-label={`${label} start time ${index + 1}`}
                                value={slot.start}
                                onChange={(e) => handleTimeChange(key, index, 'start', e.target.value)}
                                className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-1.5 text-slate-200 placeholder-slate-500 transition-colors duration-200 focus:outline-none focus:ring-2 focus:border-cyan-500 focus:ring-cyan-500/20"
                            />
                            <span className="text-slate-400">-</span>
                            <input
                                type="time"
                                aria-label={`${label} end time ${index + 1}`}
                                value={slot.end}
                                onChange={(e) => handleTimeChange(key, index, 'end', e.target.value)}
                                className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-1.5 text-slate-200 placeholder-slate-500 transition-colors duration-200 focus:outline-none focus:ring-2 focus:border-cyan-500 focus:ring-cyan-500/20"
                            />
                            <RemoveButton onClick={() => handleRemoveTimeSlot(key, index)}>
                                &times;
                            </RemoveButton>
                        </div>
                    ))}
                    <SmallButton onClick={() => handleAddTimeSlot(key)}>
                        + Add hours
                    </SmallButton>
                </div>
            </div>
        ))}
        {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
    </div>
  );
};
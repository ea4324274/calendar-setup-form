import React from 'react';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  id: string;
  error?: string;
  children?: React.ReactNode;
}

export const Textarea: React.FC<TextareaProps> = ({ label, id, error, children, ...props }) => {
  const errorClasses = 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20';
  const defaultClasses = 'border-slate-600 focus:border-cyan-500 focus:ring-cyan-500/20';
  
  return (
    <div>
      <label htmlFor={id} className="block mb-2 text-sm font-medium text-slate-300">
        {label}
        {props.required && <span className="text-red-400 ml-1">*</span>}
      </label>
      {children}
      <textarea
        id={id}
        className={`w-full bg-slate-900/50 border rounded-lg px-4 py-2.5 text-slate-200 placeholder-slate-500 transition-colors duration-200 focus:outline-none focus:ring-2 resize-y ${children ? 'mt-2' : ''} ${error ? errorClasses : defaultClasses}`}
        {...props}
      ></textarea>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
};
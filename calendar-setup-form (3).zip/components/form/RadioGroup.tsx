import React from 'react';

interface RadioGroupProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  name: string;
  options: { value: string; label: string }[];
  error?: string;
}

export const RadioGroup: React.FC<RadioGroupProps> = ({ label, name, options, value, onChange, error, required }) => {
  return (
    <div>
      <label className="block mb-2 text-sm font-medium text-slate-300">
        {label}
        {required && <span className="text-red-400 ml-1">*</span>}
      </label>
      <div className="flex items-center space-x-6">
        {options.map((option) => (
          <div key={option.value} className="flex items-center">
            <input
              id={`${name}-${option.value}`}
              name={name}
              type="radio"
              value={option.value}
              checked={value === option.value}
              onChange={onChange}
              className="h-4 w-4 border-slate-600 bg-slate-900/50 text-cyan-600 focus:ring-cyan-500/50 focus:ring-offset-slate-800 focus:ring-2 cursor-pointer"
            />
            <label htmlFor={`${name}-${option.value}`} className="ml-2 text-sm text-slate-400 cursor-pointer">
              {option.label}
            </label>
          </div>
        ))}
      </div>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
};
